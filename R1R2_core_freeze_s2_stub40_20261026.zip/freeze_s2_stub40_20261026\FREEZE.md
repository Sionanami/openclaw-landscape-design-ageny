# R1/R2 主算法冻结 s2_stub40_20261026

- 时间：2026-10-26T16:41:21.767130+08:00
- 参数：`parameters.json` / `parameters_final_s2_stub40.json`
- 要点：
  - 植被：g18_a60（window41 / close18 / hole120 / min_area60 / large_cc24）
  - 铺装：`pavement_protect_water=true`（铺装不盖水；碎屑仍硬护道路）
  - 道路：`access_stub_area_px=40`；dir=45 / gap=40 / links=2 / T=on / width_reg[1,4]
  - `prune_spur_max_px=0`（不做强短刺清除）
- 代码快照：`code_snapshot/`（SHA256 见 `code_hashes.json`）

- `core/r2/vegetation.py`: `ab5ca0e94d5717f1916e078ddbc7c56f4423b8a6b4996844f8c90c9914d93c2b`
- `core/r2/refine.py`: `3f25486be6d94edd7e9fad52fe30c8174eecbb62dfbd88111f45e2ec8869f3d3`
- `core/r2/road_connect.py`: `b76645a12b97ecca101000bff4bf8f503ebbc0ca748591233b405b9a4172b6d1`
- `core/r2/building_repair.py`: `d62749357f3b3d095fed6ec5606e5931365382cf87be7bdb2f16a14faf11fa04`
- `core/r2/surface.py`: `24aab78ae13dbd83ee332ae700fdb0982b33542bc75cf6da0a3afe2f3fce2b5c`
- `core/r2/coverage.py`: `8a069cf1feb2f340ac48b728b06eb4568e78e7fc1e73a58b61dcd56446c69cee`
- `core/r2_stages/stage_pavement.py`: `7c40642134a5c421cb5df308bc0c8c6ce7f9449d4516903ae8b2d0212962bd8b`
- `core/params/parameter_config.py`: `ff604eff38e38f3a7fa10f10eede710024961f68e4ae9acfdc79b9dc99f810f0`
- `core/r1/normalize.py`: `48e9ec6e0dae4cdbf814a2ce762ec00ad6c4661fcdbd1ca8562278b1845624eb`
- `core/generate.py`: `e7de076f1f08ce11dbd14ca760336b8501d1ed51bf771d376dc917aeb994ae72`

## 输出约定
- R2 = r2_image(R1, RAW, cons)
- R2' = r2_image(RAW, RAW, cons)

## 保留的关键实验记录（r2_test）
- `outputs_g18_a60_test120/` — 早期 g18_a60 全量测试集
- `outputs_s2_pav_no_water_dev10/` — s2 基线（stub 默认旧行为）
- `outputs_s2_r1_no_stub_dev10/` — stub=0 对照
- `outputs_s2_vs_r1_no_stub_dev10/` — s2 vs stub0 并排
- `outputs_s2_stub_area_ladder_dev10_by_view/` — stub 0/10/20/40 选型
- `outputs_selected_pc2_pipeline_dev10/` — 管线选型前身
