﻿# R1R2 核心代码包（冻结版 s2_stub40_20261026）

打包时间：2026-10-26 22:09:31
来源目录：r1r2_1026/freeze_s2_stub40_20261026

## 内容
- FREEZE.md — 冻结说明与关键参数
- parameters.json / parameters_final_s2_stub40.json — 最终参数
- code_hashes.json — 核心文件 SHA256
- code_snapshot/core/ — R1/R2 核心实现
  - core/r1/normalize.py — R1 语义归一化
  - core/r2/refine.py — R2 编排入口
  - core/r2/coverage.py — 覆盖优先级
  - core/r2/surface.py — 面状局部形态学正则
  - core/r2/building_repair.py — 建筑轮廓修复
  - core/r2/road_connect.py — 道路连通修复
  - core/r2/vegetation.py — 植被内接圆符号化
  - core/r2_stages/stage_pavement.py — 铺装/水体阶段
  - core/params/parameter_config.py — 参数解析
  - core/generate.py — 生成/管线相关

## 说明
本包为论文方法对齐所用的冻结算法快照，不含大规模实验输出与数据集。
